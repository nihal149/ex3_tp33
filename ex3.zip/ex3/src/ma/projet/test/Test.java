package ma.projet.test;

import ma.projet.classes.Employe;
import ma.projet.classes.Projet;
import ma.projet.classes.Tache;
import ma.projet.classes.EmployeTache;
import ma.projet.service.EmployeService;
import ma.projet.service.ProjetService;
import ma.projet.service.TacheService;
import ma.projet.service.EmployeTacheService;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

public class Test {

    public static void main(String[] args) throws ParseException {
        
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

       
        EmployeService employeService = new EmployeService();
        Employe employe1 = new Employe("Dupont", "Jean", "0612345678");
        employeService.create(employe1); 

        Employe employe2 = new Employe("Martin", "Claire", "0623456789");
        employeService.create(employe2); 

        Employe employe3 = new Employe("Bernard", "Luc", "0634567890");
        employeService.create(employe3); 

        
        ProjetService projetService = new ProjetService();
        Projet projet1 = new Projet("Projet Java", 
                sdf.parse("01/10/2024"), 
                sdf.parse("01/02/2025"), 
                employe1);
        projetService.create(projet1); 

        Projet projet2 = new Projet("Projet Web", 
                sdf.parse("01/11/2024"), 
                sdf.parse("01/03/2025"), 
                employe1); 
        projetService.create(projet2);

        Projet projet3 = new Projet("Projet Mobile", 
                sdf.parse("01/12/2024"),
                sdf.parse("01/04/2025"), 
                employe2);
        projetService.create(projet3); 

       TacheService tacheService = new TacheService();
        List<Tache> taches = new ArrayList<>(); 
       
        Tache tache1 = new Tache("Analyse des besoins", sdf.parse("01/10/2024"), sdf.parse("10/10/2024"), 1500.0, projet1);
        tacheService.create(tache1);
        taches.add(tache1); 

        Tache tache2 = new Tache("Développement Backend", sdf.parse("11/10/2024"), sdf.parse("15/12/2024"), 800.0, projet1);
        tacheService.create(tache2);
        taches.add(tache2);

        Tache tache3 = new Tache("Développement Frontend", sdf.parse("01/11/2024"), sdf.parse("15/01/2025"), 2000.0, projet2);
        tacheService.create(tache3);
        taches.add(tache3);
        
        
        Tache tache4 = new Tache("Tests et Validation", 
                sdf.parse("16/01/2025"), 
                sdf.parse("28/02/2025"), 
                1500.0, 
                projet2); 
        tacheService.create(tache4); 
        taches.add(tache4); 

     
        Tache tache5 = new Tache("Déploiement", 
                sdf.parse("01/03/2025"), 
                sdf.parse("01/04/2025"), 
                1000.0, 
                projet3); 
        tacheService.create(tache5); 
        taches.add(tache5); 

        EmployeTacheService employeTacheService = new EmployeTacheService();

       
        EmployeTache employeTache1 = new EmployeTache(employe1, tache1, 
                sdf.parse("01/10/2024"), 
                sdf.parse("10/10/2024")); 
        employeTacheService.create(employeTache1); 

        EmployeTache employeTache2 = new EmployeTache(employe1, tache2, 
                sdf.parse("11/10/2024"), 
                sdf.parse("15/12/2024")); 
        employeTacheService.create(employeTache2); 

        EmployeTache employeTache3 = new EmployeTache(employe2, tache3, 
                sdf.parse("01/11/2024"), 
                sdf.parse("15/01/2025"));
        employeTacheService.create(employeTache3); 

        EmployeTache employeTache4 = new EmployeTache(employe3, tache4, 
                sdf.parse("16/01/2025"),
                sdf.parse("28/02/2025"));
        employeTacheService.create(employeTache4); 

        EmployeTache employeTache5 = new EmployeTache(employe3, tache5, 
                sdf.parse("01/03/2025"), 
                sdf.parse("01/04/2025")); 
        employeTacheService.create(employeTache5); 

       
        System.out.println("Instances créées avec succès.");

        employeService.afficherTachesRealisees(employe1);
        
        employeService.afficherProjetsGeres(employe1); 
        
        projetService.afficherTachesPlanifiees(projet1); 
        
         projetService.afficherTachesRealisees(projet1);
         
         tacheService.afficherTachesAvecPrixSup1000(taches);
         
           tacheService.afficherTachesEntre(taches);
    }
}

package ma.projet.classes;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "tache")
public class Tache {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "nom", nullable = false)
    private String nom;

    @Column(name = "date_debut_reelle")
    private Date dateDebutReelle;

    @Column(name = "date_fin_reelle")
    private Date dateFinReelle;

    @Column(name = "prix")
    private double prix;  

    @ManyToOne
    @JoinColumn(name = "projet_id", referencedColumnName = "id")
    private Projet projet;

    
    public Tache() {}
 
    public Tache(String nom, Date dateDebutReelle, Date dateFinReelle, double prix, Projet projet) {
        this.nom = nom;
        this.dateDebutReelle = dateDebutReelle;
        this.dateFinReelle = dateFinReelle;
        this.prix = prix;  
        this.projet = projet;
    }
  
    public int getId() {
        return id;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public Date getDateDebutReelle() {
        return dateDebutReelle;
    }

    public void setDateDebutReelle(Date dateDebutReelle) {
        this.dateDebutReelle = dateDebutReelle;
    }

    public Date getDateFinReelle() {
        return dateFinReelle;
    }

    public void setDateFinReelle(Date dateFinReelle) {
        this.dateFinReelle = dateFinReelle;
    }

    public double getPrix() {
        return prix; // Getter pour prix
    }

    public void setPrix(double prix) {
        this.prix = prix; 
    }

    public Projet getProjet() {
        return projet;
    }

    public void setProjet(Projet projet) {
        this.projet = projet;
    }
}

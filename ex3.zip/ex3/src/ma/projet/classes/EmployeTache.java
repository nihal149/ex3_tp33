package ma.projet.classes;

import java.util.Date;
import javax.persistence.*;

@Entity
@Table(name = "employe_tache")
public class EmployeTache {
    
    

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @ManyToOne
    @JoinColumn(name = "employe_id", referencedColumnName = "id")
    private Employe employe;

    @ManyToOne
    @JoinColumn(name = "tache_id", referencedColumnName = "id")
    private Tache tache;

    @Column(name = "date_debut_reelle")
    private Date dateDebutReelle;

    @Column(name = "date_fin_reelle")
    private Date dateFinReelle;

    public EmployeTache() {}

    public EmployeTache(Employe employe, Tache tache, Date dateDebutReelle, Date dateFinReelle) {
        this.employe = employe;
        this.tache = tache;
        this.dateDebutReelle = dateDebutReelle;
        this.dateFinReelle = dateFinReelle;
    }

    public int getId() {
        return id;
    }

    public Employe getEmploye() {
        return employe;
    }

    public void setEmploye(Employe employe) {
        this.employe = employe;
    }

    public Tache getTache() {
        return tache;
    }

    public void setTache(Tache tache) {
        this.tache = tache;
    }

    public Date getDateDebutReelle() {
        return dateDebutReelle;
    }

    public void setDateDebutReelle(Date dateDebutReelle) {
        this.dateDebutReelle = dateDebutReelle;
    }

    public Date getDateFinReelle() {
        return dateFinReelle;
    }

    public void setDateFinReelle(Date dateFinReelle) {
        this.dateFinReelle = dateFinReelle;
    }
}

package ma.projet.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import ma.projet.dao.IDao;
import ma.projet.classes.Tache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ma.projet.util.HibernateUtil;

public class TacheService implements IDao<Tache> {

    private List<Tache> taches;

    @Override
    public boolean create(Tache tache) {
        Session session = null;
        Transaction tx = null;
        boolean etat = false;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(tache);  // Sauvegarde de l'objet Tache dans la base
            tx.commit();  // Validation de la transaction
            etat = true;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();  // Annulation si erreur
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return etat;
    }

    @Override
    public Tache getById(int id) {
        Session session = null;
        Tache tache = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tache = (Tache) session.get(Tache.class, id);  // Recherche par ID
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return tache;
    }

   @Override
    public List<Tache> getAll() {
        Session session = null;
        List<Tache> taches = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            taches = session.createQuery("from Tache").list();  // Requête pour obtenir toutes les tâches
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return taches;
    }

    public void afficherTachesAvecPrixSup1000(List<Tache> taches) {
        System.out.println("Liste des tâches avec prix supérieur à 1000 DH :");
        System.out.printf("%-5s %-20s %-15s %-15s %-10s%n", "Num", "Nom", "Date Début", "Date Fin", "Prix");

        boolean found = false;

        for (Tache tache : taches) {
            if (tache.getPrix() > 1000) {  
                found = true;
                System.out.printf("%-5d %-20s %-15s %-15s %.2f DH%n",
                        tache.getId(),
                        tache.getNom(),
                        tache.getDateDebutReelle(),
                        tache.getDateFinReelle(),
                        tache.getPrix());  
            }
        }

        if (!found) {
            System.out.println("Aucune tâche trouvée.");
        }
    }

    public static void afficherTachesEntre(List<Tache> taches) {
        Scanner scanner = new Scanner(System.in);
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");

        try {
            System.out.print("\nEntrez la première date (dd/MM/yyyy) : ");
            Date date1 = formatter.parse(scanner.nextLine());

            System.out.print("Entrez la deuxième date (dd/MM/yyyy) : ");
            Date date2 = formatter.parse(scanner.nextLine());

            
            if (date1.after(date2)) {
                System.out.println("Erreur : La première date doit être antérieure à la deuxième date.");
                return;
            }

            System.out.println("\nTâches réalisées entre " + formatter.format(date1) + " et " + formatter.format(date2) + " :");
            taches.stream()
                    .filter(tache -> {
                        Date dateDebutReelle = tache.getDateDebutReelle();
                        Date dateFinReelle = tache.getDateFinReelle(); 
                       
                        return (dateDebutReelle.equals(date1) || dateDebutReelle.after(date1)) &&
                               (dateFinReelle.equals(date2) || dateFinReelle.before(date2));
                    })
                    .forEach(tache -> System.out.println("Tâche{id=" + tache.getId() +
                            ", nom='" + tache.getNom() +
                            "', date début='" + formatter.format(tache.getDateDebutReelle()) +
                            "', date fin='" + formatter.format(tache.getDateFinReelle()) + 
                            "', prix=" + tache.getPrix() + " DH}"));  
        } catch (ParseException e) {
            System.out.println("Erreur de format de date : " + e.getMessage());
        } catch (Exception e) {
            System.out.println("Une autre erreur est survenue : " + e.getMessage());
        } finally {
            scanner.close();
        }
    }
}

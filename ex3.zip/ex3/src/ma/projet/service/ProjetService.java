package ma.projet.service;

import ma.projet.dao.IDao;
import ma.projet.classes.Projet;
import ma.projet.classes.Tache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ma.projet.util.HibernateUtil;

import java.util.List;

public class ProjetService implements IDao<Projet> {

    @Override
    public boolean create(Projet projet) {
        Session session = null;
        Transaction tx = null;
        boolean etat = false;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(projet);  // Sauvegarde de l'objet Projet dans la base
            tx.commit();  // Validation de la transaction
            etat = true;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();  // Annulation si erreur
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return etat;
    }

       @Override
    public Projet getById(int id) {
        Session session = null;
        Projet projet = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            projet = (Projet) session.get(Projet.class, id);  // Recherche par ID
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return projet;
    }


     @Override
    public List<Projet> getAll() {
        Session session = null;
        List<Projet> projets = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            projets = session.createQuery("from Projet").list();  // Requête pour obtenir tous les projets
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return projets;
    }

    
    public void afficherTachesPlanifiees(Projet projet) {
        if (projet.getTaches() == null || projet.getTaches().isEmpty()) {
            System.out.println("Aucune tâche planifiée pour ce projet.");
            return;
        }

        System.out.println("Tâches planifiées pour le projet : " + projet.getNom());

        for (Tache tache : projet.getTaches()) {
            System.out.println("ID Tâche : " + tache.getId());
            System.out.println("Nom Tâche : " + tache.getNom());
            System.out.println("Date de début prévue : " + tache.getDateDebutReelle());
            System.out.println("Date de fin prévue : " + tache.getDateFinReelle());
            System.out.println("Prix estimé : " + tache.getPrix());
            System.out.println("-----------------------------");
        }
    }
    
    public void afficherTachesRealisees(Projet projet) {
        System.out.println("Projet : " + projet.getId() + " Nom : " + projet.getNom() + 
                           " Date début : " + projet.getDateDebutPrevue());

        System.out.println("Liste des tâches :");
        System.out.printf("%-5s %-20s %-15s %-15s%n", "Num", "Nom", "Date Début Réelle", "Date Fin Réelle");
        
        if (projet.getTaches() == null || projet.getTaches().isEmpty()) {
            System.out.println("Aucune tâche réalisée pour ce projet.");
            return;
        }

        for (Tache tache : projet.getTaches()) {
            if (tache.getDateDebutReelle() != null && tache.getDateFinReelle() != null) {
                System.out.printf("%-5d %-20s %-15s %-15s%n", 
                                  tache.getId(), 
                                  tache.getNom(), 
                                  tache.getDateDebutReelle(), 
                                  tache.getDateFinReelle());
            }
        }
    }
}

package ma.projet.service;

import java.util.ArrayList;
import ma.projet.dao.IDao;
import ma.projet.classes.Employe;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ma.projet.util.HibernateUtil;

import java.util.List;
import ma.projet.classes.EmployeTache;
import ma.projet.classes.Projet;
import ma.projet.classes.Tache;

public class EmployeService implements IDao<Employe> {

    @Override
   
    public boolean create(Employe employe) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            tx = session.beginTransaction();
            session.save(employe); // Cela peut provoquer une NullPointerException
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx != null) tx.rollback();
            e.printStackTrace();
            return false;
        } finally {
            session.close();
        }
    }

    @Override
    public Employe getById(int id) {
        Session session = null;
        Employe employe = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            employe = (Employe) session.get(Employe.class, id);  // Recherche par ID
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return employe;
    }

    @Override
    public List<Employe> getAll() {
        Session session = null;
        List<Employe> employes = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            employes = session.createQuery("from Employe").list();  // Requête pour obtenir tous les employés
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return employes;
       
    }
    
     //1
    public void afficherTachesRealisees(Employe employe) {
        
       

        System.out.println("Tâches réalisées par " + employe.getNom() + " :");


        for (EmployeTache employeTache : employe.getTaches()) {
            System.out.println("ID Tâche : " + employeTache.getTache().getId());
            System.out.println("Nom Tâche : " + employeTache.getTache().getNom());
            System.out.println("Date de début réelle : " + employeTache.getDateDebutReelle());
            System.out.println("Date de fin réelle : " + employeTache.getDateFinReelle());
            System.out.println("-----------------------------");
        }
    }
    //2
  public void afficherProjetsGeres(Employe employe) {
       
        if (employe == null) {
            System.out.println("L'employé est null !");
            return;
        }

        System.out.println("Projets gérés par " + employe.getNom() + " :");

        
        for (Projet projet : obtenirProjetsParEmploye(employe)) {  
            if (projet != null) {
                System.out.println("ID Projet : " + projet.getId());
                System.out.println("Nom Projet : " + projet.getNom());
                System.out.println("Date de début prévue : " + projet.getDateDebutPrevue());
                System.out.println("Date de fin prévue : " + projet.getDateFinPrevue());
                System.out.println("-----------------------------");
            }
        }
    }

    // Méthode fictive pour obtenir les projets d'un employé
    private List<Projet> obtenirProjetsParEmploye(Employe employe) {
        List<Projet> projets = new ArrayList<>();
        
        // Logique pour récupérer les projets gérés par l'employé
        // Cela peut être une requête à la base de données ou toute autre source de données
        // Ajoutez ici la logique appropriée pour remplir la liste projets

        return projets; // Retourne la liste des projets
    }
}



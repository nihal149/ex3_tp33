package ma.projet.service;

import ma.projet.dao.IDao;
import ma.projet.classes.EmployeTache;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;
import ma.projet.util.HibernateUtil;

import java.util.List;

public class EmployeTacheService implements IDao<EmployeTache> {

    @Override
    public boolean create(EmployeTache employeTache) {
        Session session = null;
        Transaction tx = null;
        boolean etat = false;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            session.save(employeTache);  
            tx.commit(); 
            etat = true;
        } catch (HibernateException e) {
            if (tx != null) tx.rollback();  
            e.printStackTrace();
        } finally {
            if (session != null) session.close(); 
        }
        return etat;
    }

    @Override
    public EmployeTache getById(int id) {
        Session session = null;
        EmployeTache employeTache = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            employeTache = (EmployeTache) session.get(EmployeTache.class, id); 
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close(); 
        }
        return employeTache;
    }

    @Override
    public List<EmployeTache> getAll() {
        Session session = null;
        List<EmployeTache> employeTaches = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            employeTaches = session.createQuery("from EmployeTache").list();  // Requête pour obtenir toutes les tâches des employés
        } catch (HibernateException e) {
            e.printStackTrace();
        } finally {
            if (session != null) session.close();  // Fermeture de la session
        }
        return employeTaches;
    }
}
